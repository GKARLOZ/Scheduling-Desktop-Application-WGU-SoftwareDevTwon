


Title:
 Database Application 

Purpose:
 Users can add Customers and add appointments for the customers.

Author:
 Giancarlo Bustos

Contact Information: 
 
Student Application version: 

 C195 V 09 

Date:

 05/14/2021


IDE VERSION:

 Apache NetBeans IDE 11.0

JDK:

 JDK 11 (Default) jdk-11.0.10

JavaFx:

 JavaFX Scene Builder 11.0.0

Directions:

 Install the right versions of each application and run the code. A login screen should pop up when you run the program. 

Additional Report:

 The additional report is in the customer records interface at the bottom of the table view. 
 When the user press the country report button, it will show a report of the total customers for each country. 


MySQL Connector Driver:

 mysql-connector-java-8.0.22

 
 
 
 